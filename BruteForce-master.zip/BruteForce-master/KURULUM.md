###Kurulum :
```
git clone https://github.com/thelinuxchoice/instashell
cd instashell
chmod +x insta.sh
service tor start
sudo ./insta.sh
```

### Install.sh yetki verme:

```
chmod +x install.sh
sudo ./install.sh
```

### TurkHackTeam
https://turkhackteam.org
###############################
#                             #
# Editor :                    #
#         TheWinson           #
#  TURKHACKTEAM               #
#                             #
###############################
